﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using YiyinCSharp.Tools;

namespace YiyinCSharp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private FrameConfig config = new FrameConfig();
        private string[] selectedFiles;
        
        private void btnSelect_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "图片|*.jpg;*.jpeg;*.png";
                ofd.Multiselect = true;

                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    selectedFiles = ofd.FileNames;
                    // lblCount.Text = "已选：" + selectedFiles.Length + " 张";
                    ShowPreview(selectedFiles[0]);
                }
            }
        }

        // ✅ 这就是你要的 ShowPreview 完整方法
        private void ShowPreview(string imgPath)
        {
            try
            {
                string temp = Path.Combine(Path.GetTempPath(), "preview.jpg");
                YiyinEngine.Render(imgPath, temp, config);

                using (FileStream fs = new FileStream(temp, FileMode.Open))
                {
                    // pictureBox.Image = System.Drawing.Image.FromStream(fs);
                }
            }
            catch { }
        }

        private async void btnStart_Click(object sender, EventArgs e)
        {
            //参考ZZZNote.md
        }
    }
}