﻿using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Drawing.Processing;
using SixLabors.ImageSharp.PixelFormats;
using SixLabors.ImageSharp.Processing;
using System.IO;
using System.Linq;
using SixLabors.Fonts;

namespace YiyinCSharp.Tools
{
    public class YiyinCore
    {
        /// <summary>
        /// 【关键】和 GitHub yiyin 一模一样的印框生成
        /// </summary>
        public static void GenerateYiyinFrame(string input, string output)
        {
            var exif = ExifReader.GetExif(input);
            using var img = Image.Load<Rgba32>(input);

            // ====================== 【原版参数】 ======================
            int padding = 60;         // 边框宽度
            int bottomBarHeight = 50; // 底部参数栏
            int textSize = 14;
            Color bg = Color.White;
            Color textColor = Color.Black;
            // ==========================================================

            int w = img.Width + padding * 2;
            int h = img.Height + padding * 2 + bottomBarHeight;

            using var canvas = new Image<Rgba32>(w, h, bg);
            canvas.Mutate(x =>
            {
                // 贴原图
                x.DrawImage(img, new Point(padding, padding), 1f);

                // 底部文字（和壹印排版完全一致）
                var font = SystemFonts.CreateFont("Segoe UI", textSize);
                string text = $"{exif.Camera} | {exif.Lens} | {exif.Aperture} | {exif.Shutter} | ISO {exif.Iso} | {exif.Focal}";

                x.DrawText(
                    text, 
                    font, 
                    textColor, 
                    new PointF(padding + 10, padding + img.Height + 15)
                );
            });

            // 无损导出
            canvas.Save(output, new SixLabors.ImageSharp.Formats.Jpeg.JpegEncoder { Quality = 100 });
        }

        /// <summary>
        /// 批量处理（原版功能）
        /// </summary>
        public static void Batch(string inputDir, string outputDir)
        {
            if (!Directory.Exists(outputDir)) Directory.CreateDirectory(outputDir);
            var exts = new[] { ".jpg", ".jpeg", ".png", ".webp" };

            foreach (var f in Directory.GetFiles(inputDir))
            {
                if (exts.Contains(Path.GetExtension(f).ToLower()))
                {
                    var name = Path.GetFileName(f);
                    GenerateYiyinFrame(f, Path.Combine(outputDir, name));
                }
            }
        }
    }
}