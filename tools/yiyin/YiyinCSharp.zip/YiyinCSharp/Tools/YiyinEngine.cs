﻿using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Drawing.Processing;
using SixLabors.ImageSharp.PixelFormats;
using SixLabors.ImageSharp.Processing;
using System.IO;
using SixLabors.Fonts;
using Path = System.IO.Path;

namespace YiyinCSharp.Tools
{
    public class YiyinEngine
    {
        public static void Render(string input, string output, FrameConfig cfg)
        {
            ExifInfo exif = ExifTool.Read(input);

            // 加载图片
            using (Image<Rgba32> img = Image.Load<Rgba32>(input))
            {
                // 画布尺寸
                int canvasW = img.Width + cfg.Padding * 2;
                int canvasH = img.Height + cfg.Padding * 2 + cfg.BottomBarHeight;
                Color bgColor = Color.ParseHex(cfg.BgColor);

                // 创建画布
                using (Image<Rgba32> canvas = new Image<Rgba32>(canvasW, canvasH))
                {
                    // 填充背景
                    SixLabors.ImageSharp.Processing.ProcessingExtensions.Mutate(canvas, ctx => { ctx.Fill(bgColor); });

                    // 绘制原图（无圆角，彻底避免API报错）
                    SixLabors.ImageSharp.Processing.ProcessingExtensions.Mutate(canvas,
                        ctx => { ctx.DrawImage(img, new Point(cfg.Padding, cfg.Padding), 1f); });

                    // 绘制EXIF文字
                    var font = SystemFonts.CreateFont("Segoe UI", cfg.TextSize);
                    string text =
                        $"{exif.Camera} | {exif.Lens} | {exif.Aperture} | {exif.Shutter} | ISO {exif.Iso} | {exif.Focal}";

                    SixLabors.ImageSharp.Processing.ProcessingExtensions.Mutate(canvas, ctx =>
                    {
                        ctx.DrawText(text, font, Color.ParseHex(cfg.TextColor),
                            new PointF(cfg.Padding + 10, cfg.Padding + img.Height + 15));
                    });

                    // 保存
                    canvas.Save(output, new SixLabors.ImageSharp.Formats.Jpeg.JpegEncoder
                    {
                        Quality = 100
                    });
                }
            }
        }

        /// <summary>
        /// 批量处理
        /// </summary>
        public static void BatchProcess(string[] files, string outDir, FrameConfig cfg,
            System.Action<int, int> progress)
        {
            if (!Directory.Exists(outDir))
                Directory.CreateDirectory(outDir);

            for (int i = 0; i < files.Length; i++)
            {
                string file = files[i];
                string savePath = Path.Combine(outDir, Path.GetFileName(file));
                Render(file, savePath, cfg);
                progress?.Invoke(i + 1, files.Length);
            }
        }
    }
}