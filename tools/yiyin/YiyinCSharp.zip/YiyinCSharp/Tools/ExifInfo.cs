﻿namespace YiyinCSharp.Tools
{
    public class ExifInfo
    {
        public string Camera { get; set; } = "Unknown Camera";
        public string Lens { get; set; } = "Unknown Lens";
        public string Aperture { get; set; } = "f/1.8";
        public string Shutter { get; set; } = "1/100";
        public string Iso { get; set; } = "100";
        public string Focal { get; set; } = "50mm";
        public string DateTime { get; set; } = "";
    }
}