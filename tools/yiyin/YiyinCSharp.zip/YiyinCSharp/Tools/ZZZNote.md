﻿




```csharp
using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace YiyinFinal
{
    public partial class MainForm : Form
    {
        private FrameConfig config = new FrameConfig();
        private string[] selectedFiles;

        public MainForm()
        {
            InitializeComponent();
            Text = "Yiyin 1.6.0 复刻版";
            Size = new Size(900, 600);
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "图片|*.jpg;*.jpeg;*.png";
                ofd.Multiselect = true;

                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    selectedFiles = ofd.FileNames;
                    lblCount.Text = "已选：" + selectedFiles.Length + " 张";
                    ShowPreview(selectedFiles[0]);
                }
            }
        }

        // ✅ 这就是你要的 ShowPreview 完整方法
        private void ShowPreview(string imgPath)
        {
            try
            {
                string temp = Path.Combine(Path.GetTempPath(), "preview.jpg");
                YiyinEngine.Render(imgPath, temp, config);

                using (FileStream fs = new FileStream(temp, FileMode.Open))
                {
                    pictureBox.Image = System.Drawing.Image.FromStream(fs);
                }
            }
            catch { }
        }

        private async void btnStart_Click(object sender, EventArgs e)
        {
            if (selectedFiles == null || selectedFiles.Length == 0)
            {
                MessageBox.Show("请选择图片");
                return;
            }

            btnStart.Enabled = false;
            string outDir = Path.Combine(Application.StartupPath, "output");

            await System.Threading.Tasks.Task.Run(() =>
            {
                YiyinEngine.Batch(selectedFiles, outDir, config, (curr, total) =>
                {
                    Invoke((Action)(() =>
                    {
                        progressBar.Value = curr;
                        lblProgress.Text = curr + "/" + total;
                    }));
                });
            });

            MessageBox.Show("处理完成！\n导出到：" + outDir);
            btnStart.Enabled = true;
        }

        #region 窗体控件自动生成
        private PictureBox pictureBox;
        private Label lblCount;
        private ProgressBar progressBar;
        private Label lblProgress;
        private Button btnSelect;
        private Button btnStart;

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            pictureBox = new PictureBox
            {
                Size = new Size(520, 400),
                Location = new Point(20, 20),
                SizeMode = PictureBoxSizeMode.Zoom,
                BorderStyle = BorderStyle.FixedSingle
            };

            lblCount = new Label { Location = new Point(20, 430), AutoSize = true };
            progressBar = new ProgressBar { Location = new Point(20, 450), Size = new Size(520, 25) };
            lblProgress = new Label { Location = new Point(550, 450), AutoSize = true };

            btnSelect = new Button { Text = "选择图片", Location = new Point(570, 50), Size = new Size(120, 35) };
            btnStart = new Button { Text = "批量生成", Location = new Point(570, 100), Size = new Size(180, 40), BackColor = Color.LightGreen };

            Controls.Add(pictureBox);
            Controls.Add(lblCount);
            Controls.Add(progressBar);
            Controls.Add(lblProgress);
            Controls.Add(btnSelect);
            Controls.Add(btnStart);

            btnSelect.Click += btnSelect_Click;
            btnStart.Click += btnStart_Click;
            progressBar.Maximum = 100;
        }
        #endregion
    }
}
```