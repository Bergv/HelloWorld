﻿using MetadataExtractor;
using MetadataExtractor.Formats.Exif;
using System;
using System.Linq;

namespace YiyinCSharp.Tools
{
    // 边框配置
    public class FrameConfig
    {
        public int Padding { get; set; } = 60;
        public int BottomBarHeight { get; set; } = 50;
        public int CornerRadius { get; set; } = 12;
        public string BgColor { get; set; } = "#FFFFFF";
        public string TextColor { get; set; } = "#1A1A1A";
        public float TextSize { get; set; } = 15;
    }
    
    
    public static class ExifTool
    {
        public static ExifInfo Read(string path)
        {
            var info = new ExifInfo();
            try
            {
                var dirs = ImageMetadataReader.ReadMetadata(path);
                var ifd0 = dirs.OfType<ExifIfd0Directory>().FirstOrDefault();
                var sub = dirs.OfType<ExifSubIfdDirectory>().FirstOrDefault();

                if (ifd0 != null && ifd0.ContainsTag(ExifIfd0Directory.TagModel))
                    info.Camera = ifd0.GetDescription(ExifIfd0Directory.TagModel);

                if (sub == null) return info;

                if (sub.ContainsTag(ExifSubIfdDirectory.TagLensModel))
                    info.Lens = sub.GetDescription(ExifSubIfdDirectory.TagLensModel);

                if (sub.ContainsTag(ExifSubIfdDirectory.TagFNumber))
                    info.Aperture = sub.GetDescription(ExifSubIfdDirectory.TagFNumber).Replace("F", "f/");

                if (sub.ContainsTag(ExifSubIfdDirectory.TagExposureTime))
                    info.Shutter = sub.GetDescription(ExifSubIfdDirectory.TagExposureTime);

                // 2.9.3 正确ISO
                if (sub.ContainsTag(ExifSubIfdDirectory.TagIsoSpeed))
                    info.Iso = sub.GetDescription(ExifSubIfdDirectory.TagIsoSpeed);

                if (sub.ContainsTag(ExifSubIfdDirectory.TagFocalLength))
                    info.Focal = sub.GetDescription(ExifSubIfdDirectory.TagFocalLength);

                if (sub.ContainsTag(ExifSubIfdDirectory.TagDateTimeOriginal))
                    info.DateTime = sub.GetDescription(ExifSubIfdDirectory.TagDateTimeOriginal);
            }
            catch { }
            return info;
        }
    }
    public static class ExifReader
    {
        public static ExifInfo GetExif(string path)
        {
            var model = new ExifInfo();
            try
            {
                var meta = ImageMetadataReader.ReadMetadata(path);
                var ifd0 = meta.OfType<ExifIfd0Directory>().FirstOrDefault();
                var sub = meta.OfType<ExifSubIfdDirectory>().FirstOrDefault();

                // 相机
                if (ifd0 != null && ifd0.ContainsTag(ExifIfd0Directory.TagModel))
                    model.Camera = ifd0.GetDescription(ExifIfd0Directory.TagModel);

                // 镜头
                if (sub != null && sub.ContainsTag(ExifSubIfdDirectory.TagLensModel))
                    model.Lens = sub.GetDescription(ExifSubIfdDirectory.TagLensModel);

                // 光圈
                if (sub != null && sub.ContainsTag(ExifSubIfdDirectory.TagFNumber))
                    model.Aperture = sub.GetDescription(ExifSubIfdDirectory.TagFNumber).Replace("F", "f/");

                // 快门
                if (sub != null && sub.ContainsTag(ExifSubIfdDirectory.TagExposureTime))
                    model.Shutter = sub.GetDescription(ExifSubIfdDirectory.TagExposureTime);

                // ISO
                if (sub != null && sub.ContainsTag(ExifSubIfdDirectory.TagIsoSpeed))
                    model.Iso = sub.GetDescription(ExifSubIfdDirectory.TagIsoSpeed);

                // 焦距
                if (sub != null && sub.ContainsTag(ExifSubIfdDirectory.TagFocalLength))
                    model.Focal = sub.GetDescription(ExifSubIfdDirectory.TagFocalLength);

                // 时间
                if (sub != null && sub.ContainsTag(ExifSubIfdDirectory.TagDateTimeOriginal))
                    model.DateTime = sub.GetDescription(ExifSubIfdDirectory.TagDateTimeOriginal);
            }
            catch { }
            return model;
        }
    }
}