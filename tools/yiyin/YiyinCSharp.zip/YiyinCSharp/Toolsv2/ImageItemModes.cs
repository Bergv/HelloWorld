﻿using System.Collections.Generic;

namespace YiyinCSharp.Toolsv2
{
    // 对应 OutputOption
    public class OutputOption
    {
        public bool Iot { get; set; }
        public bool Landscape { get; set; }
        public bool SolidBg { get; set; }
        public string SolidColor { get; set; } = "#FFFFFF";
        public Ratio BgRate { get; set; } = new Ratio();
        public bool BgRateShow { get; set; }
        public bool OriginWhOutput { get; set; }
        public int Radius { get; set; }
        public bool RadiusShow { get; set; }
        public int Shadow { get; set; }
        public bool ShadowShow { get; set; }
        public string Font { get; set; }
        public int MainImgWRate { get; set; } = 90;
        public int TextMargin { get; set; }
        public int Quality { get; set; } = 100;
        public int MiniTopBottomMargin { get; set; }
        public int BgBlur { get; set; } = 100;
    }

   // 辅助类：比例
    public class Ratio
    {
        public int W { get; set; }
        public int H { get; set; }
    }

    // 对应 OutputFilePaths
    public class OutputFilePaths
    {
        public string Base { get; set; }
        public string Bg { get; set; }
        public string Main { get; set; }
        public string Mask { get; set; }
        public string Composite { get; set; }
    }

    // 对应 SizeInfo
    public class SizeInfo
    {
        public int W { get; set; }
        public int H { get; set; }
        public int ResetW { get; set; }
        public int ResetH { get; set; }
    }

// 对应 Material + Img
    public class Material
    {
        public Img Bg { get; set; } = new Img();
        public List<Img> Main { get; set; } = new List<Img>();
        public List<Img> Text { get; set; } = new List<Img>();
    }

    public class Img
    {
        public string Path { get; set; }
        public byte[] Buf { get; set; }
        public int W { get; set; }
        public int H { get; set; }
        public int Top { get; set; }
        public int Left { get; set; }
    }
}