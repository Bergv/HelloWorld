﻿



```csharp
var opt = new OutputOption
{
    SolidBg = true,
    SolidColor = "#FFFFFF",
    RadiusShow = true,
    Radius = 12,
    Quality = 100,
    MiniTopBottomMargin = 5
};

var tool = new ImageTool(
    imagePath: "C:\\test.jpg",
    name: "test.jpg",
    cachePath: "C:\\yiyin_cache",
    outputPath: "C:\\yiyin_output",
    outputOpt: opt
);

tool.ProgressChanged += (id, p) => {
    // 进度条
    // progressBar1.Value = p;
};

tool.StartProcess();
MessageBox.Show("完成！");
```


