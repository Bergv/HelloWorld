﻿using System;
using System.IO;
using System.Threading.Tasks;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Drawing.Processing;
using SixLabors.ImageSharp.Formats.Jpeg;
using SixLabors.ImageSharp.PixelFormats;
using SixLabors.ImageSharp.Processing;
using Directory = System.IO.Directory;

namespace YiyinCSharp.Toolsv2
{
    // 进度回调委托
    public delegate void ProgressChangedHandler(string id, int progress);

    public class ImageTool
    {
        public event Action<string, int> ProgressChanged;

        private int _progress;
        private bool _isInit;
        private SizeInfo _sizeInfo = new SizeInfo();
        private OutputOption _outputOpt;
        private Material _material = new Material();
        private int _contentH;

        // 已按你要求重命名：Path → ImagePath
        public string Id { get; }
        public string ImagePath { get; }
        public string Name { get; }
        public string CachePath { get; }
        public string OutputPath { get; }

        public ImageTool(string imagePath, string name, string cachePath, string outputPath, OutputOption outputOpt)
        {
            ImagePath = imagePath;
            Name = name;
            CachePath = cachePath;
            OutputPath = outputPath;
            _outputOpt = outputOpt;
            Id = Guid.NewGuid().ToString("N");

            if (!Directory.Exists(cachePath)) Directory.CreateDirectory(cachePath);
            if (!Directory.Exists(outputPath)) Directory.CreateDirectory(outputPath);
        }

        private int Progress
        {
            get => _progress;
            set
            {
                _progress = value;
                ProgressChanged?.Invoke(Id, _progress);
            }
        }

        // 🔥 核心异步入口（你要的 StartProcessAsync）
        public async System.Threading.Tasks.Task StartProcessAsync()
        {
            Progress = 10;
            await InitAsync();
            Progress = 20;
            CalcBgImgSize();
            Progress = 30;
            await GenMainImgAsync();
            Progress = 50;
            CalcContentHeight();
            Progress = 70;
            await GenSolidBgAsync();
            Progress = 90;
            await CompositeAsync();
            Progress = 100;
        }

        // 主流程（对齐 yiyin 1.6.0）
        public void StartProcess()
        {
            Progress = 10;
            Init();
            Progress = 20;
            CalcBgImgSize();
            Progress = 30;
            GenMainImg();
            Progress = 50;
            CalcContentHeight();
            Progress = 70;
            GenSolidBg();
            Progress = 90;
            Composite();
            Progress = 100;
        }

        public void Init()
        {
            if (_isInit) return;
            _isInit = true;

            using (var img = Image.Load(ImagePath))
            {
                _sizeInfo.W = img.Width;
                _sizeInfo.H = img.Height;
                _sizeInfo.ResetW = img.Width;
                _sizeInfo.ResetH = img.Height;
            }
        }

        public async Task InitAsync()
        {
            if (_isInit) return;
            _isInit = true;
            using (var img = await Image.LoadAsync(ImagePath))
            {
                _sizeInfo.W = img.Width;
                _sizeInfo.H = img.Height;
                _sizeInfo.ResetW = img.Width;
                _sizeInfo.ResetH = img.Height;
            }
        }

        public void CalcBgImgSize(int height = 0)
        {
            int resetW = _sizeInfo.ResetW;
            int resetH = _sizeInfo.ResetH;

            if (height > 0)
            {
                double whRate = (double)resetW / resetH;
                resetH = height;
                resetW = (int)Math.Round(resetH * whRate);
            }

            _material.Bg.W = resetW;
            _material.Bg.H = resetH;
        }

        public async Task GenMainImgAsync()
        {
            using (var img = await Image.LoadAsync(ImagePath))
            {
                img.Mutate(x => x.AutoOrient());
                string mainPath = Path.Combine(CachePath, $"{Id}_main.jpg");
                await img.SaveAsync(mainPath, new JpegEncoder { Quality = 100 });
                _material.Main.Add(new Img
                {
                    Path = mainPath,
                    W = img.Width,
                    H = img.Height,
                    Left = 0,
                    Top = 0
                });
            }
        }

        public void GenMainImg()
        {
            using (var img = Image.Load(ImagePath))
            {
                img.Mutate(x => x.AutoOrient());

                if (_outputOpt.RadiusShow && _outputOpt.Radius > 0)
                {
                    img.Mutate(x => x.Resize(img.Width, img.Height));
                }

                string mainPath = Path.Combine(CachePath, $"{Id}_main.jpg");
                img.Save(mainPath, new JpegEncoder { Quality = 100 });

                _material.Main.Add(new Img
                {
                    Path = mainPath,
                    W = img.Width,
                    H = img.Height,
                    Left = 0,
                    Top = 0
                });
            }
        }

        public void GenSolidBg()
        {
            int w = _material.Bg.W;
            int h = _material.Bg.H;
            string bgPath = Path.Combine(CachePath, $"{Id}_bg.jpg");

            using (var bg = new Image<Rgb24>(w, h))
            {
                bg.Mutate(x => x.Fill(Color.ParseHex(_outputOpt.SolidColor)));
                bg.Save(bgPath, new JpegEncoder { Quality = _outputOpt.Quality });
            }

            _material.Bg.Path = bgPath;
        }

        public async Task GenSolidBgAsync()
        {
            int w = _material.Bg.W;
            int h = _material.Bg.H;
            string bgPath = Path.Combine(CachePath, $"{Id}_bg.jpg");
            using (var bg = new Image<Rgb24>(w, h))
            {
                bg.Mutate(x => x.Fill(Color.ParseHex(_outputOpt.SolidColor)));
                await bg.SaveAsync(bgPath, new JpegEncoder { Quality = _outputOpt.Quality });
            }

            _material.Bg.Path = bgPath;
        }

        public void CalcContentHeight()
        {
            // 修复 Any()
            if (_material.Main.Count == 0) return;

            var opt = _outputOpt;
            var bgHeight = _material.Bg.H;
            int mainImgTopOffset = (int)Math.Round(bgHeight * ((double)opt.MiniTopBottomMargin / 100.0));
            int contentTop = Math.Max(mainImgTopOffset, 20);

            // 修复 Sum()
            int textH = 0;
            foreach (var t in _material.Text) textH += t.H;

            int mainH = _material.Main[0].H;
            // 修复 Math.Ceiling 歧义
            _contentH = (int)Math.Ceiling((double)(textH + mainH + contentTop * 2));

            _material.Main[0].Top = contentTop;

            // 修复 Last()
            if (_material.Text.Count > 0)
            {
                Img last = _material.Text[_material.Text.Count - 1];
                last.H += (int)Math.Round((double)bgHeight * 0.027);
            }
        }

        public void Composite()
        {
            string outFile = Path.Combine(OutputPath, $"{Path.GetFileNameWithoutExtension(Name)}_{Id}.jpg");
            using (var canvas = new Image<Rgb24>(_material.Bg.W, _material.Bg.H))
            {
                // 画背景
                using (var bg = Image.Load(_material.Bg.Path))
                    canvas.Mutate(x => x.DrawImage(bg, new Point(0, 0), 1f));

                // 画主图
                foreach (var m in _material.Main)
                    using (var img = Image.Load(m.Path))
                        canvas.Mutate(x => x.DrawImage(img, new Point(m.Left, m.Top), 1f));

                // 画文字（修复 Reverse()）
                int textTop = _material.Bg.H;
                for (int i = _material.Text.Count - 1; i >= 0; i--)
                {
                    var textImg = _material.Text[i];
                    textTop -= textImg.H;
                    int left = (_material.Bg.W - textImg.W) / 2;

                    // 修复 Load 歧义：明确调用 byte[]
                    using (var img = Image.Load((byte[])textImg.Buf))
                        canvas.Mutate(x => x.DrawImage(img, new Point(left, textTop), 1f));
                }

                canvas.Save(outFile, new JpegEncoder { Quality = _outputOpt.Quality });
            }
        }

        public async Task CompositeAsync()
        {
            string outFile = Path.Combine(OutputPath, $"{Path.GetFileNameWithoutExtension(Name)}_{Id}.jpg");
            using (var canvas = new Image<Rgb24>(_material.Bg.W, _material.Bg.H))
            {
                // 绘制背景
                using (var bg = await Image.LoadAsync(_material.Bg.Path))
                    canvas.Mutate(ctx => ctx.DrawImage(bg, new Point(0, 0), 1f));

                // 绘制主图
                foreach (var m in _material.Main)
                {
                    using (var img = await Image.LoadAsync(m.Path))
                        canvas.Mutate(ctx => ctx.DrawImage(img, new Point(m.Left, m.Top), 1f));
                }

                // 绘制文字（修复：byte[] → MemoryStream → LoadAsync）
                int textTop = _material.Bg.H;
                for (int i = _material.Text.Count - 1; i >= 0; i--)
                {
                    var t = _material.Text[i];
                    textTop -= t.H;
                    int left = (_material.Bg.W - t.W) / 2;

                    using (var ms = new MemoryStream(t.Buf))
                    using (var img = await Image.LoadAsync(ms))
                    {
                        canvas.Mutate(ctx => ctx.DrawImage(img, new Point(left, textTop), 1f));
                    }
                }

                await canvas.SaveAsync(outFile, new JpegEncoder { Quality = _outputOpt.Quality });
            }
        }
    }
}