document.addEventListener('DOMContentLoaded', function() {
  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    var activeTab = tabs[0];
    chrome.cookies.getAll({ url: activeTab.url }, function(cookies) {
      if (cookies.length > 0) {
        var cookieStr = cookies.map(c => `${c.name}=${c.value}`).join('; ');
        document.getElementById('cookieInfo').innerText = cookieStr;
        copyButton.disabled = false; // 可以复制
      } else {
        document.getElementById('errorInfo').innerText = '无法获取到 Cookie';
        copyButton.disabled = true; // 禁用复制按钮
      }
    });
  });

  document.getElementById('copyButton').addEventListener('click', function() {
    var cookieInfo = document.getElementById('cookieInfo');
    var textWithoutNewline = cookieInfo.innerText.replace(/\n/g, ''); // 去掉换行符
    var tempInput = document.createElement("input");
    tempInput.value = textWithoutNewline;
    document.body.appendChild(tempInput);
    tempInput.select();
    document.execCommand('copy');
    document.body.removeChild(tempInput);
    alert('Cookie已复制到剪贴板！');
  });


});
