# N_m3u8DL-CLI-SimpleG
N_m3u8DL-CLI's simple GUI

---

对应命令行工具：https://github.com/nilaoda/N_m3u8DL-CLI

相关说明：https://nilaoda.github.io/N_m3u8DL-CLI/SimpleGUI.html

没什么精力维护，开源

![image](https://user-images.githubusercontent.com/20772925/153235235-712b338e-4e2a-4a77-8b3b-119bceb45f24.png)
