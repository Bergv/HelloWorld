﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;

namespace DpExcel2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var wb = new XSSFWorkbook();
            var sheet = wb.CreateSheet("test");
            var row = sheet.CreateRow(0);
            
            var cell = row.CreateCell(0);
            var style = wb.CreateCellStyle();
            style.FillPattern = FillPattern.SolidForeground;
            style.FillForegroundColor = IndexedColors.BrightGreen.Index;
            cell.CellStyle = style;
            cell.SetCellValue("xx");
            
            
            var cell1 = row.CreateCell(1);
            var style1 = (XSSFCellStyle)wb.CreateCellStyle();
            var myColor = new XSSFColor(new byte[] {85,206,255});
            style1.SetFillForegroundColor(myColor);
            style1.FillPattern = FillPattern.SolidForeground;
            cell1.CellStyle = style1;
            cell1.SetCellValue("1");


            using (FileStream fs = File.OpenWrite("test2.xlsx"))
            {
                wb.Write(fs,false);
            }
        }
    }
}